export interface UserData {
  name: string;
  language: string;
  experience: string;
  goals: string;
  projectType: string;
  challenges: string[];
}